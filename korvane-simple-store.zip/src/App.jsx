import React, { useState } from "react";

export default function App() {
  const [cart, setCart] = useState([]);

  const products = [
    { id: 1, name: "Luxury Signature Tee", price: 65 },
    { id: 2, name: "Korvane Street Hoodie", price: 120 },
    { id: 3, name: "Performance Sport Set", price: 95 },
    { id: 4, name: "Korvane Fishing Jersey", price: 85 },
  ];

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div style={{padding:"40px"}}>
      <h1 style={{textAlign:"center",letterSpacing:"4px"}}>KORVANE</h1>
      <h2 style={{textAlign:"center"}}>Elevate Every Style</h2>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:"20px",marginTop:"40px"}}>
        {products.map((product) => (
          <div key={product.id} style={{background:"#111",padding:"20px",borderRadius:"10px"}}>
            <div style={{height:"100px",background:"#222",marginBottom:"10px"}}></div>
            <h3>{product.name}</h3>
            <p>${product.price}</p>
            <button onClick={() => addToCart(product)} style={{width:"100%",padding:"8px",background:"white",color:"black",border:"none",borderRadius:"5px"}}>
              Add to Cart
            </button>
          </div>
        ))}
      </div>

      <div style={{marginTop:"50px",background:"#111",padding:"20px",borderRadius:"10px"}}>
        <h3>Cart Summary</h3>
        {cart.length === 0 ? (
          <p>Your cart is empty.</p>
        ) : (
          <>
            {cart.map((item, index) => (
              <div key={index} style={{display:"flex",justifyContent:"space-between"}}>
                <span>{item.name}</span>
                <span>${item.price}</span>
              </div>
            ))}
            <div style={{marginTop:"10px",fontWeight:"bold",display:"flex",justifyContent:"space-between"}}>
              <span>Total:</span>
              <span>${total}</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
